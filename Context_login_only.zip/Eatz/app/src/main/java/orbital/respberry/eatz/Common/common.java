package orbital.respberry.eatz.Common;

import orbital.respberry.eatz.Model.User;

public class common {
    public static User currentUser;
}

